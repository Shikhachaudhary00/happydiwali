
# Diwali Fire Rockets Effect 🎆

Created a unique and glowing Javascript Project of Fire Rockets Effect using HTML5 Canvas. These Rockets are generated randomly and have random glowing color, get burst when reached a point and explodes sparkling particles.
Do Watch the video tutorial of this Project to get the concept.

[🔴 Youtube Tutorial Video](https://youtu.be/YGpzeUUuvKE)

[🔵 Live Project URL](https://teenageprogrammer.github.io/Diwali-Fire-Rockets-Effect-Javascript/)





## Screenshot

![App Screenshot](https://i.ibb.co/t8kgpb1/Thumbnail.png)


## 🚀 About Me
Teenage Programmer - Developing unique projects and trying to make web development learning easy to freshy users in this field. Fast track your development career with me. Hope you'll love my creativity.


[SUBSCRIBE YOUTUBE](https://www.youtube.com/channel/UCHpW7UyMQf0SXpdO0obb1ig)


![App Screenshot](https://yt3.ggpht.com/oGB27ubPR1zD7eqatjSUZRnMqdr1WAV6g3wC39d-G0hFTIrkzq0FK5_Z9sgAGQsTHEzOOgSw=s88-c-k-c0x00ffffff-no-rj)
